import pandas as pd
from mootdx.quotes import Quotes
from datetime import datetime

# 股票代码和起始日期输入
symbol = '300779'
start_date = '20240601'  # 输入的开始日期，格式为'YYYYMMDD'
end_date = '20240906'  # 一年后的结束日期

# 生成日期范围，一年内的每个交易日
date_range = pd.date_range(start=start_date, end=end_date)

# 初始化参数
client = Quotes.factory(market='std')
offset = 10

# 初始化一个空的DataFrame用于存储每天的统计结果，列名改为中文
summary_df = pd.DataFrame(columns=['日期', '大单买入次数', '大单卖出次数', '小单买入次数', '小单卖出次数'])

# 遍历每个日期获取数据
for single_date in date_range:
    date_str = single_date.strftime('%Y%m%d')  # 转换日期为字符串格式 'YYYYMMDD'

    all_data = pd.DataFrame()  # 存储单天的数据
    start = 0

    try:
        while True:
            # 获取数据
            df = client.transactions(symbol=symbol, start=start, offset=offset, date=date_str)

            # 如果获取不到数据，结束循环
            if df.empty:
                break

            # 拼接数据
            all_data = pd.concat([df, all_data])

            # 更新start，下一次从start开始取数据
            start += offset

        # 如果当天没有数据，跳过该日期
        if all_data.empty:
            print(f"日期 {date_str} 没有数据，跳过。")
            continue

        # 将时间列转换为日期时间格式
        all_data['time'] = pd.to_datetime(all_data['time'], format='%H:%M')

        # 1. 计算当天所有成交量的平均值
        avg_volume = all_data['volume'].mean()

        # 2. 定义大单和小单的分类（根据成交量是否大于平均值）
        all_data['order_size'] = all_data['volume'].apply(lambda x: '大单' if x > avg_volume else '小单')

        # 3. 统计当天的大单和小单的买入和卖出次数
        large_buy_count = len(all_data[(all_data['order_size'] == '大单') & (all_data['buyorsell'] == 0)])
        large_sell_count = len(all_data[(all_data['order_size'] == '大单') & (all_data['buyorsell'] == 1)])

        small_buy_count = len(all_data[(all_data['order_size'] == '小单') & (all_data['buyorsell'] == 0)])
        small_sell_count = len(all_data[(all_data['order_size'] == '小单') & (all_data['buyorsell'] == 1)])

        # 4. 将当天的统计结果添加到summary_df，使用pd.concat代替append
        summary_df = pd.concat([summary_df, pd.DataFrame({
            '日期': [date_str],
            '大单买入次数': [large_buy_count],
            '大单卖出次数': [large_sell_count],
            '小单买入次数': [small_buy_count],
            '小单卖出次数': [small_sell_count]
        })], ignore_index=True)
        print('+1')

    except Exception as e:
        print(f"处理日期 {date_str} 时出错，错误信息: {e}")
        continue  # 出现错误时跳过该日期

# 最终的summary_df中包含了一年内每天的统计结果
print(summary_df)
summary_df.to_excel('xxxx.xlsx')