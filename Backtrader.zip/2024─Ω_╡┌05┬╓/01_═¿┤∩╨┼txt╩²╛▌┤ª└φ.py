import random
import numpy as np
import pyautogui
import pandas as pd
import pyperclip
import time
import os
import win32com.client as win32
import pickle
import time
import datetime
import dask.dataframe as dd
from  自定义函数.MyTT import *
from 自定义函数.likai自定义函数 import  *
开始时间 = time.time()

np.set_printoptions(precision=None, suppress=True)
np.set_printoptions(threshold=np.inf)
# 设置输出右对齐
pd.set_option('display.unicode.east_asian_width', True)
# 显示所有的列
pd.set_option('expand_frame_repr', False)
# 最多显示数据的行数
pd.set_option('display.max_rows', 2000)
# 取消科学计数法,显示完整,可调整小数点后显示位数
pd.set_option('display.float_format', '{:.2f}'.format)


def 通达信实现(df):
    # 处理每个股票代码的数据，生成新的DataFrame，并将其合并
    result = pd.concat([通达信策略(group) for _, group in df.groupby('股票代码')], ignore_index=True)
    return result



# 导出的格式是 XXXXXX.txt  分割号是（;）,日期格式默认
# 通达信数据txt导入并处理合并
if       0    :
    不复权_路径 = r'C:\Users\79122\Desktop\通达信txt下载_不复权'
    后复权_路径 = r'C:\Users\79122\Desktop\通达信txt下载_后复权'
    result_df_不复权 = 批量读取通达信txt股票(不复权_路径)
    result_df_后复权 = 批量读取通达信txt股票(后复权_路径)
    result_df_不复权.to_pickle('00通达信txt数据处理/通达信txt所有股票_不复权.pkl')
    result_df_后复权.to_pickle('00通达信txt数据处理/通达信txt所有股票_后复权.pkl')
    df_all_时间对齐版本_后复权 = 时间列对齐数据补全(result_df_后复权)
    df_all_时间对齐版本_后复权.to_pickle('00通达信txt数据处理/通达信txt所有股票_后复权_时间对齐_回测专用.pkl')
    print(result_df_不复权.shape)
    print(result_df_后复权.shape)
    print(df_all_时间对齐版本_后复权.shape)
    exit()






# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
def 通达信策略old001(df) :
    OPEN  =  O  = df.open.values
    HIGH  =  H  = df.high.values
    LOW   =  L  = df.low.values
    CLOSE =  C  = df.close.values
    VOL   =  V  = df.volume.values
    AMO   =       df.amount.values
    TR = to_TR(C,H,L)
    DIF,  DEA,  MACD=  GET_MACD(CLOSE)
    SAR =  TDX_SAR(H,L)
    #### 上面是基础定义 ########
    # 波动 = TR
    # 波动5 = EMA(波动, 5)
    # 波动10 = EMA(波动, 10)
    # 波动5X = EMA(波动, 5)
    # 波动10X = EMA(波动, 10)
    # 天数 = BARSLASTCOUNT(波动5 < 波动10)
    MA5  = MA(C, 5)
    MA10 = MA(C, 10)
    MA20 = MA(C, 20)
    MA30 = MA(C, 30)
    MA60 = MA(C, 60)
    国力 =  (MA30-MA60)/MA60*100 + (MA20-MA30)/MA30*100 + (MA10-MA20)/MA20*100+(MA5-MA10)/MA10*100
    国力天数 = BARSLASTCOUNT(国力>0)
    国力位置 = IF(国力 > 0  , (国力 - LLV(国力, 国力天数)) / (HHV(国力, 国力天数) - LLV(国力, 国力天数)) * 100 , 0)
    价格位置 = IF(国力 > 0 , (C - LLV(LOW, 国力天数)) / (HHV(HIGH, 国力天数) - LLV(LOW, 国力天数)) * 100, 0)
    df['国力']=国力
    df['国力天数'] = 国力天数
    df['国力位置'] = 国力位置
    df['价格位置'] = 价格位置
    SAR低于天数 =  BARSLASTCOUNT( SAR > C)
    df['SAR'] = TDX_SAR(H, L)
    df['SAR低于天数'] = SAR低于天数
    df['未来'] =  IF (  BARSNEXT(CLOSE/REF(C,1) > 1.09  ) ==1  ,1,0   )
    # df['历史日最低价'] = LLV(C,0)
    # df['MACD低于天数'] =  BARSLASTCOUNT( (国力>0 ) & ( MACD<0)  )
    return df




def 通达信策略(df) :
    OPEN  =  O  = df.open.values
    HIGH  =  H  = df.high.values
    LOW   =  L  = df.low.values
    CLOSE =  C  = df.close.values
    VOL   =  V  = df.volume.values
    AMO   =       df.amount.values
    TR = to_TR(C,H,L)
    DIF,  DEA,  MACD=  GET_MACD(CLOSE)
    SAR =  TDX_SAR(H,L)
    #### 上面是基础定义 ########
    return df


















# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################
# todo  #### 选股中心  指标计算  ################################




df_base  = pd.read_pickle('00通达信txt数据处理/通达信txt所有股票_不复权.pkl')


# 检查文件是否存在
if os.path.exists('通达信实现.pkl'):
    print('存在指标')
    df = pd.read_pickle('通达信实现.pkl')
else :
    print('开始计算指标')
    时间戳  = time.time()
    df = 通达信实现(df_base)
    print( time.time() -时间戳   )
    df.to_pickle('通达信实现.pkl')

print(zhao(df,20240822,0,'volume',0).head(100)  )






# 字典 保存为 pickle 文件
交易清单dict  = 所有股票交易点导出(  df ,'volume' ,3, 0)
with open("00通达信txt数据处理/交易清单.pkl", "wb") as f:
    pickle.dump(交易清单dict, f)















