import random
import numpy as np
import pyautogui
import pandas as pd
import pyperclip
import time
import os
import win32com.client as win32
import pickle
import time
import datetime

from  自定义函数.MyTT import *
from 自定义函数.likai自定义函数 import  *
开始时间 = time.time()

np.set_printoptions(precision=None, suppress=True)
np.set_printoptions(threshold=np.inf)
# 设置输出右对齐
pd.set_option('display.unicode.east_asian_width', True)
# 显示所有的列
pd.set_option('expand_frame_repr', False)
# 最多显示数据的行数
pd.set_option('display.max_rows', 2000)
# 取消科学计数法,显示完整,可调整小数点后显示位数
pd.set_option('display.float_format', '{:.2f}'.format)




def 转换xls()    :   # 先清空，再转换xlsx成xls
    MOFA_删除里面所有文件除了文件夹(xlsx路径)
    MOFA_转换xls(xls路径, xlsx路径)
    MOFA_删除里面所有文件除了文件夹(xls路径)

def  读取更新的xlsx()  :   #  使用该函数读取和拼接 Excel 文件
    文件夹路径 = xlsx路径  # 修改为你的文件夹路径
    df = 读取拼接成df(文件夹路径)
    df = df.dropna(subset=['收盘'])  # 删除收盘这一列下，有空的行
    df = df.rename(columns={'代码': '股票代码','开盘价': 'open', '最高价': 'high', '最低价': 'low', '收盘价': 'close', '成交量': 'volume', '成交金额': 'amount'})
    return df



def 通达信实现(df):
    # 处理每个股票代码的数据，生成新的DataFrame，并将其合并
    result = pd.concat([通达信策略(group) for _, group in df.groupby('股票代码')], ignore_index=True)
    return result


# 策略编写 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def 通达信策略(df) :
    df.sort_values(by=['日期'], ascending=True, inplace=True)
    OPEN  =  O  = df.open.values
    HIGH  =  H  = df.high.values
    LOW   =  L  = df.low.values
    CLOSE =  C  = df.close.values
    VOL   =  V  = df.volume.values
    AMO   =       df.amount.values
    TR = to_TR(C,H,L)
    DIF,  DEA,  MACD=  GET_MACD(CLOSE)
    #### 上面是基础定义 别动 ########
    MA5  = MA(C, 5)
    MA10 = MA(C, 10)
    MA20 = MA(C, 20)
    MA30 = MA(C, 30)
    MA60 = MA(C, 60)
    国力 =  (MA30-MA60)/MA60*100 + (MA20-MA30)/MA30*100 + (MA10-MA20)/MA20*100+(MA5-MA10)/MA10*100
    df['MA5'] =MA5
    df['MA10'] =MA10
    df['MA20'] =MA20
    df['MA30'] =MA30
    df['MA60'] =MA60
    df['国力'] = 国力
    return df








# todo ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
xls路径 =  r'C:\Users\79122\Desktop\Backtrader\2024年_第03轮\00通达信数据下载\xls'
xlsx路径 = r'C:\Users\79122\Desktop\Backtrader\2024年_第03轮\00通达信数据下载\xlsx'

# 转换xls()
# 读取更新的xlsx()

df_base = pd.read_pickle('00通达信数据下载/股票校对存档.pkl')

df = 通达信实现(df_base)



# print( zhao(  df ,20240409 ,0 ,'收盘')  )
# print(len( zhao(  df ,20240409 ,0 ,'收盘')['股票代码'].unique().tolist()    ) )
# df = zhao(  df ,20240410 ,0 ,'国力')  # 重置索引并删除原索引列
# df.reset_index(drop=True, inplace=True)
# print(df.head(50))
# exit()





# 交易买点导出字典
交易_字典  = 所有股票交易点导出(  df ,'国力' ,5, 0)
with open("00数据存储/买入清单xls.pkl", "wb") as f:
    pickle.dump(交易_字典, f)

print(交易_字典 )


