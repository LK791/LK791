import random
import numpy as np
import pyautogui
import pandas as pd
import pyperclip
import time
import os
import win32com.client as win32
import pickle
import time
from  自定义函数.MyTT import *
from 自定义函数.likai自定义函数 import  *
from mootdx.reader import Reader
开始时间 = time.time()

np.set_printoptions(precision=None, suppress=True)
np.set_printoptions(threshold=np.inf)
# 设置输出右对齐
pd.set_option('display.unicode.east_asian_width', True)
# 显示所有的列
pd.set_option('expand_frame_repr', False)
# 最多显示数据的行数
pd.set_option('display.max_rows', 8000)
# 取消科学计数法,显示完整,可调整小数点后显示位数
pd.set_option('display.float_format', '{:.2f}'.format)








# 读取通达信本地数据，然后保存pkl
if     os.path.exists("00数据存储/通达信本地数据.pkl")  :
    print('通过--------通达信本地数据-----通达信本地数据(时间对齐版本) ----已导出')
else  :
    df_list = pd.read_excel(r'C:\Users\79122\Desktop\Backtrader\2024年_第03轮\00数据存储\目标股票.xlsx', skiprows=0)[:-1]
    目标股票list = df_list.iloc[:, 0].tolist()
    # 目标股票list = [  '000001', '000023']
    # print(目标股票list  )
    # print(len(目标股票list))
    # exit()
    df_all = 读取通达信本地数据(目标股票list)
    df_all_时间对齐版本 = 时间列对齐数据补全(df_all)
    df_all.to_pickle('00数据存储/通达信本地数据.pkl')
    df_all_时间对齐版本.to_pickle('00数据存储/通达信本地数据(时间对齐版本).pkl')
    print('* ' * 30)
    print('OK~~~成功导出')
    print('* ' * 30)




##### 选股中心  指标计算  ################################
def 通达信(df) :
    OPEN  =  O  = df.open.values
    HIGH  =  H  = df.high.values
    LOW   =  L  = df.low.values
    CLOSE =  C  = df.close.values
    VOL   =  V  = df.volume.values
    AMO   =       df.amount.values
    TR = to_TR(C,H,L)
    DIF,  DEA,  MACD=  GET_MACD(CLOSE)
    #### 上面是基础定义 ########
    # 波动 = TR
    # 波动5 = EMA(波动, 5)
    # 波动10 = EMA(波动, 10)
    # 波动5X = EMA(波动, 5)
    # 波动10X = EMA(波动, 10)
    # 天数 = BARSLASTCOUNT(波动5 < 波动10)
    MA5  = MA(C, 5)
    MA10 = MA(C, 10)
    MA20 = MA(C, 20)
    MA30 = MA(C, 30)
    MA60 = MA(C, 60)
    国力 =  (MA30-MA60)/MA60*100 + (MA20-MA30)/MA30*100 + (MA10-MA20)/MA20*100+(MA5-MA10)/MA10*100
    # 国力天数 = BARSLASTCOUNT(国力>0)
    # 国力位置 = IF(国力 > 0  , (国力 - LLV(国力, 国力天数)) / (HHV(国力, 国力天数) - LLV(国力, 国力天数)) * 100 , 0)
    # 价格位置 = IF(国力 > 0 , (C - LLV(LOW, 国力天数)) / (HHV(HIGH, 国力天数) - LLV(LOW, 国力天数)) * 100, 0)
    df['国力']=国力
    # df['国力天数'] = 国力天数
    # df['国力位置'] = 国力位置
    # df['价格位置'] = 价格位置
    # df['历史日最低价'] = LLV(C,0)
    # df['MACD低于天数'] =  BARSLASTCOUNT( (国力>0 ) & ( MACD<0)  )
    # df['SAR'] =  TDX_SAR(H,L)
    return df

#########################################################


df_base = pd.read_pickle('00数据存储/通达信本地数据.pkl')
df = df_base
# print(df.columns)
df_临时传递 = [通达信(group) for code, group in df.groupby('股票代码')]
df = pd.concat(df_临时传递, ignore_index=True)
# df.to_pickle('00数据存储/通达信本地数据(带计算好的指标).pkl')
print(  zhao(df,20240801 ,0,'国力'   ) )
print('* ' * 30)
print('OK~~~成功导出')
print('* ' * 30)

exit()


# 买入清单 计算导出

if     os.path.exists("00数据存储/买入清单.pkl")  :
    print('通过--------交易清单---已导出')
else  :
    df = pd.read_pickle('00数据存储/通达信本地数据(带计算好的指标).pkl')
    交易点_dict_all  = 所有股票交易点导出(  df ,'MACD低于天数' ,5, 0)
    # 字典 保存为 pickle 文件
    with open("00数据存储/买入清单.pkl", "wb") as f:
        pickle.dump(交易点_dict_all, f)
    print('* ' * 30)
    print('OK~~~成功导出')
    print('* ' * 30)





df = pd.read_pickle('00数据存储/通达信本地数据.pkl')
print(df.columns)
#
# with open("00数据存储/买入清单.pkl", "rb") as f:
#     交易清单 = pickle.load(f)
# print( 交易清单   )
# print( type(交易清单)   )
# print(  zhao(df,20200423,0))




print( time.time() - 开始时间)