import random
import numpy as np
import pyautogui
import pandas as pd
import pyperclip
import time
import os
import win32com.client as win32
import pickle
import time
from  自定义函数.MyTT import *
from 自定义函数.likai自定义函数 import  *
开始时间 = time.time()

np.set_printoptions(precision=None, suppress=True)
np.set_printoptions(threshold=np.inf)
# 设置输出右对齐
pd.set_option('display.unicode.east_asian_width', True)
# 显示所有的列
pd.set_option('expand_frame_repr', False)
# 最多显示数据的行数
pd.set_option('display.max_rows', 8000)
# 取消科学计数法,显示完整,可调整小数点后显示位数
pd.set_option('display.float_format', '{:.2f}'.format)
















xls路径 = r'C:\Users\79122\Desktop\Backtrader\2024年_第03轮\00通达信数据下载\no_xls'
已处理成xlsx路径 = r'C:\Users\79122\Desktop\Backtrader\2024年_第03轮\00通达信数据下载\yes_xlsx'



if    0    :   # 先清空，再转换xlsx成xls
    MOFA_删除里面所有文件除了文件夹(已处理成xlsx路径)
    MOFA_转换xls(xls路径, 已处理成xlsx路径)


if    0    :   #  使用该函数读取和拼接 Excel 文件
    文件夹路径 = 已处理成xlsx路径  # 修改为你的文件夹路径
    拼接后的df = 读取拼接成df(文件夹路径)
    拼接后的df.to_pickle('拼接结果_带日期.pkl')
    # 拼接后的df.to_excel("拼接后的数据.xlsx", index=False, sheet_name='拼接数据')



# todo ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------





df = pd.read_pickle('../拼接结果_带日期.pkl')

df_基础版  = df

def 通达信(df) :
    CLOSE =  C  =   df.收盘价.values
    OPEN  =  O  = df.开盘价.values
    HIGH  =  H  = df.最高价.values
    LOW   =  L  = df.最低价.values
    VOL   =  df.成交量.values


    df['ma5'] = BARSLASTCOUNT(C>REF(C,1))
    return df



df_sss = [通达信(group) for code, group in df.groupby('代码')]
df = pd.concat(df_sss, ignore_index=True)
df.to_excel('合并股票.xlsx', index=False)

print(df)