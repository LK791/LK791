import random
import numpy as np
import pyautogui
import pandas as pd
import pyperclip
import time
import os
import win32com.client as win32
import pickle
from 自定义函数.likai自定义函数 import  *

# import h5py
np.set_printoptions(precision=None, suppress=True)
np.set_printoptions(threshold=np.inf)
# 设置输出右对齐
pd.set_option('display.unicode.east_asian_width', True)
# 显示所有的列
pd.set_option('expand_frame_repr', False)
# 最多显示数据的行数
pd.set_option('display.max_rows', 8000)
# 取消科学计数法,显示完整,可调整小数点后显示位数
pd.set_option('display.float_format', '{:.8f}'.format)




导出股票的个数  =  3000


for XXXX in range( 导出股票的个数 ):
    开始时间 = time.time()
    time.sleep(1)
    pyautogui.click(1700, 25)
    time.sleep(0.2)
    pyautogui.press('[')
    time.sleep(0.5)
    识别器 = 0
    while 识别器 == 0:
        image_path = '00通达信数据下载/识别黑块.png'
        region = (1349, 714, 84, 68)
        # 在指定区域内查找图片
        for i in range(90):
            try:
                location = pyautogui.locateOnScreen(image_path, region=region)
                if location is not None:
                    # print( '完成')
                    识别器 = 1
                    # left, top, width, height = location
                    # center_x = left + width / 2
                    # center_y = top + height / 2
                    # # pyautogui.click(center_x, center_y)
                    break
            except pyautogui.ImageNotFoundException:
                pass
            time.sleep(0.3)  # 等待1秒再次尝试
            # print('再等0.2秒')
    pyautogui.press('3')
    time.sleep(0.1)
    pyautogui.press('4')
    time.sleep(0.2)
    pyautogui.press('enter')
    time.sleep(1)
    pyautogui.press('enter')
    time.sleep(1.5)
    pyautogui.press('esc')
    print( '进度', XXXX ,'/',导出股票的个数 )
    print("单个耗时：", 小数2点(time.time() - 开始时间), "秒")














