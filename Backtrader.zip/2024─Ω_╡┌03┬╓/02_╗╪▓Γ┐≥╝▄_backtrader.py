import random
import numpy as np
import pyautogui
import pandas as pd
import pyperclip
import time
import os
import backtrader as bt
import win32com.client as win32
import pickle
from collections import defaultdict
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import time
from  自定义函数.MyTT import *
from 自定义函数.likai自定义函数 import  *
from mootdx.reader import Reader
开始时间 = time.time()

np.set_printoptions(threshold=np.inf)  # 打印所有数据
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用于正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用于正常显示负号
pd.set_option('display.unicode.east_asian_width', True)# 设置输出右对齐
pd.set_option('expand_frame_repr', False)# 显示所有的列
pd.set_option('display.max_rows', 5000)# 最多显示数据的行数
pd.set_option('display.float_format', '{:.2f}'.format) # 取消科学计数法,显示完整,可调整小数点后显示位数


















# todo 数据输入 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

读取股票个数 = 60     # 全部导入填 None
初始本金 = 500000
开始日期 = 20150101
结束日期 = 20241230






with open("00数据存储/买入清单.pkl", "rb") as f:
    交易清单 = pickle.load(f)

df = pd.read_pickle('00数据存储/通达信本地数据(时间对齐版本).pkl')
df = df[df['股票代码'].isin(df['股票代码'].unique()[:读取股票个数])]
df['股票代码2'] = df['股票代码']

# print(df)
# print(df.columns)
# print(df['股票代码'].iloc[1])
# exit()

# todo 定义函数 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def feed投喂(df ,cerebro ) :
    股票名字 =  str(df['股票代码2'].iloc[0])
    data = bt.feeds.PandasData(
        dataname=df,
        fromdate=日期(开始日期),
        todate=   日期(结束日期),
        datetime='日期',
        open='open',
        high='high',
        low='low',
        close='close',
        volume='volume',
        openinterest=-1  ,
        plot = False    ,    # 超级重要，false就是不用画图了，当我导入了1000只股票，那就非常重要
    )
    cerebro.adddata(data , name= 股票名字 )
    global 计数a
    计数a= 计数a+1
    print(  计数a )


# 中国佣金
class ChinaStockCommission(bt.CommInfoBase):  # 中国股票 佣金与印花税
    params = (
        ('stamp_duty', 0.001),  # 印花税
        ('commission_rate', 0.0015),  # 佣金率  很多干到了 万分之2.5，我设置千分之1 算高了
        ('min_commission', 5),  # 最低佣金
        ('stamp_duty_applicable', True),  # 是否收取印花税
    )

    def _getcommission(self, size, price, pseudoexec):
        # size 为交易股数，price 为交易价格
        commission = abs(size) * price * self.p.commission_rate
        # 佣金不低于最低标准
        commission = max(commission, self.p.min_commission)

        # 如果是卖出交易并且收取印花税，印花税是成交金额的百分比
        if size < 0 and self.p.stamp_duty_applicable:
            stamp_duty = abs(size) * price * self.p.stamp_duty
            commission += stamp_duty

        return commission




# todo 策略定义--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class 空策略(bt.Strategy):

    def log(self, txt, dt=None):
        '''可选，构建策略打印日志的函数：可用于打印订单记录或交易记录等'''
        dt = dt or self.datas[0].datetime.date(0)
        print('%s, %s' % (dt.isoformat(), txt))

    def __init__(self):
        '''必选，初始化属性、计算指标等'''
        pass

    def notify_order(self, order):
        '''可选，打印订单信息'''
        pass

    def notify_trade(self, trade):
        '''可选，打印交易信息'''
        pass


    def next(self):
        '''必选，编写交易策略逻辑'''
        当天 = self.datetime.datetime(0)
        print(当天.date())
        print(当天)

        pass



class 空策略001(bt.Strategy):

    def __init__(self):
        '''必选，初始化属性、计算指标等'''
        self.最后一天 = self.datas[0].datetime.date(len(self.datas[0]) - 1)
        pass


    def next(self):
        '''必选，编写交易策略逻辑'''
        持仓列表 = [abc._name for abc in self.broker.positions if self.broker.getposition(abc).size > 0]
        if self.datetime.date(0) > self.最后一天 -timedelta(days=3) :
            print('=' * 88)
            print(self.datetime.date(0))
            for i in 持仓列表:
                self.close(i)
            print(持仓列表)
            print('最后3天,触发全部平仓')
            return
        当天 = self.datetime.datetime(0)
        print(当天)

        print(  持仓列表)
        if  not 持仓列表 :
            # self.buy(self.datas[0] , size=10)
            self.order = self.order_target_percent(target=0.99)
        if  持仓列表 :
            self.close(self.datas[0] )

        print(  持仓列表)
        pass



    def stop(self):
        # 策略运行结束时调用
        print('=' * 88)
        print('初始本金:', 初始本金)
        print( '策略结束时： 钱+股票   : ',小数2点(self.broker.getvalue()))
        print( '策略结束时:   钱: ',小数2点(self.broker.getcash()))
        pass

class 空策略002(bt.Strategy):

    def __init__(self):
        '''必选，初始化属性、计算指标等'''
        self.最后一天 = self.datas[0].datetime.date(len(self.datas[0]) - 1)
        pass


    def next(self):
        持仓列表 = [abc._name for abc in self.broker.positions if self.broker.getposition(abc).size > 0]
        if self.datetime.date(0) > self.最后一天 -timedelta(days=3) :
            print('=' * 88)
            print(self.datetime.date(0))
            for i in 持仓列表:
                self.close(i)
            print(持仓列表)
            print('最后3天,触发全部平仓')
            return
        当天 = self.datetime.datetime(0)
        print(当天)
        print(  持仓列表)
        if  not 持仓列表 :
            # self.buy(self.datas[0] , size=10)
            self.order = self.order_target_percent(target=0.99)
        if  持仓列表 :
            self.close(self.datas[0] )

        print(  持仓列表)
        pass



    def stop(self):
        # 策略运行结束时调用
        print('=' * 88)
        print('初始本金:', 初始本金)
        print( '策略结束时： 钱+股票   : ',小数2点(self.broker.getvalue()))
        print( '策略结束时:   钱: ',小数2点(self.broker.getcash()))
        pass

















# todo 主程序设置 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


cerebro = bt.Cerebro(
    stdstats=False ,     # 推荐打开，默认是True,观察器选择False,然后我再自己添加，那样就不会有股票数据了
    )
cerebro.broker.set_coc(True) # 用途：适合在当前 bar 内（即在当前时间段的结束时）立即执行基于收盘价的订单的策略

# 调用投喂函数,开始投喂df
if not os.path.exists('回测缓存文件.pkl'):
    print('不存在_回测缓存文件________开始加载')
    计数a = 0
    df.groupby('股票代码').apply(lambda df: feed投喂(df, cerebro), include_groups=False)
else:
    print('存在_回测缓存文件_______开始欺骗餐')
    df测试 = 欺骗餐()
    data测试 = bt.feeds.PandasData(dataname=df测试)
    cerebro.adddata( data测试 )


cerebro.broker.setcash(初始本金)   # 设置初始资金
cerebro.broker.set_slippage_fixed(fixed=0.01)  # 双边固定0.01滑点 ，不计算到交易成本
cerebro.broker.setcommission(commission=0.002)   # 设置固定双边 手续费比例
# cerebro.broker.addcommissioninfo(ChinaStockCommission())      # 中国股票 佣金与印花税


cerebro.addstrategy(      空策略002     )     # 添加策略
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trade_analyzer')  #交易分析
cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')   # 夏普
cerebro.addanalyzer(bt.analyzers.Returns, _name='returns')   # 年回报
cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')   #  最大回撤分析器
cerebro.addobserver(bt.observers.Broker)  # 资金曲线
cerebro.addobserver(bt.observers.Trades)  #  交易胜率分布
cerebro.addobserver(bt.observers.DrawDown)  # 最大回撤

if not os.path.exists('回测缓存文件.pkl'):
    results = cerebro.run(save_my_data=True)  # 保存缓存,再运行
else :
    results = cerebro.run(load_my_data=True)  # 加载缓存,再运行

trade_analyzer = results[0].analyzers.trade_analyzer.get_analysis()
sharpe_ratio = results[0].analyzers.sharpe.get_analysis()
returns = results[0].analyzers.returns.get_analysis()
drawdown = results[0].analyzers.drawdown.get_analysis()
max_drawdown = drawdown.get('max', {}).get('drawdown', None)
print('=' * 88)
print( 交易分析(trade_analyzer) )
print("夏普比率:", sharpe_ratio)
print(f"最大回撤: {max_drawdown:.2f}%" if max_drawdown is not None else "没有回撤数据")
print(f"总回报率: {returns['rtot'] * 100:.2f}%")  # `rtot` 表示总回报率
print(f"年度回报率: {returns['rnorm'] * 100:.2f}%")  # `rnorm` 表示年度化回报率
print('初始本金:', 初始本金)
print('=' * 88)

cerebro.plot(   )
print("运行时间：", 小数2点(time.time() - 开始时间), "秒")