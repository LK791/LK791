import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, log_loss

# 示例数据
X = np.array([[1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15]])  # 特征数据

# 对应的目标数据
y = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1])

# 数据分割
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 数据标准化（对训练集和测试集分别进行）
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)  # 训练集标准化
X_test_scaled = scaler_X.transform(X_test)        # 测试集标准化


# 调整 C 和 gamma 参数
svc = SVC(kernel='rbf', C=10, gamma=0.1, probability=True)

# 训练模型
svc.fit(X_train_scaled, y_train)

# 进行预测
y_pred = svc.predict(X_test_scaled)
y_pred_proba = svc.predict_proba(X_test_scaled)  # 获取每个样本的类别概率

# 计算准确率和对数损失
accuracy = accuracy_score(y_test, y_pred)
logloss = log_loss(y_test, y_pred_proba, labels=[0, 1])

print(f'Accuracy: {accuracy}')
print(f'Log Loss: {logloss}')
print('测试集', X_test)
print('实际值:', y_test)
print('预测值:', y_pred)
print('预测概率:', y_pred_proba)
