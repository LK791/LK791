import random
import numpy as np
import pyautogui
import pandas as pd
import pyperclip
import time
import os
import win32com.client as win32
import pickle
import time
import datetime
from mootdx.reader import Reader
import dask.dataframe as dd
import concurrent.futures


开始时间 = time.time()

np.set_printoptions(precision=None, suppress=True)
np.set_printoptions(threshold=np.inf)
# 设置输出右对齐
pd.set_option('display.unicode.east_asian_width', True)
# 显示所有的列
pd.set_option('expand_frame_repr', False)
# 最多显示数据的行数
pd.set_option('display.max_rows', 8000)
# 取消科学计数法,显示完整,可调整小数点后显示位数
pd.set_option('display.float_format', '{:.8f}'.format)








def MOFA_删除里面所有文件除了文件夹(已处理成xlsx路径 ) :
    # 删除目标文件夹下所有文件,只留空文件夹
    for root, dirs, files in os.walk(AA88):
        # 删除文件夹里的文件
        for file in files:
            file_path = os.path.join(root, file)
            os.remove(file_path)
    print('清理导出目录')
    print('* ' * 30)

def MOFA_转换xls(xls路径, 已处理成xlsx路径) :
    aaa = -1
    # 另存为xlsx的文件路径（GBK编码）
    for file in os.scandir(xls路径):
        suffix = file.name.split(".")[-1]
        if file.is_dir():
            pass
        else:
            if suffix == "xls":
                excel = win32.gencache.EnsureDispatch('Excel.Application')
                wb = excel.Workbooks.Open(file.path)
                # 将文件路径转换为GBK编码
                xlsx_path = 已处理成xlsx路径.encode('gbk')
                # xlsx文件夹路径\\文件名x
                wb.SaveAs(xlsx_path.decode('gbk') + "\\" + file.name + "x", FileFormat=51)
                wb.Close()
                excel.Application.Quit()
        aaa = aaa+1
        print( 'ok '+str(aaa)   )
    print('xls转换xlsx完成 ')
    print('* '*30)

def MOFA_删除里面所有文件除了文件夹(已处理成xlsx路径 ) :
    # 删除目标文件夹下所有文件,只留空文件夹
    for root, dirs, files in os.walk(已处理成xlsx路径):
        # 删除文件夹里的文件
        for file in files:
            file_path = os.path.join(root, file)
            os.remove(file_path)
    print('清理导出目录')
    print('* ' * 30)


def 读取拼接成df(文件夹路径):
    df_总 = pd.DataFrame()
    文件数 = 0
    文件列表 = []

    # 遍历文件夹中的所有文件
    for 文件名 in os.listdir(文件夹路径):
        if 文件名.endswith('.xlsx'):
            完整路径 = os.path.join(文件夹路径, 文件名)

            # 提取日期部分
            日期 = 文件名.replace('全部Ａ股', '').replace('.xlsx', '')

            try:
                日期 = pd.to_datetime(日期 )
            except ValueError:
                print(f"日期格式错误: {日期}.")
                continue

            try:
                # 读取 Excel 文件
                df = pd.read_excel(完整路径, skiprows=1).iloc[:-1]

                # 加入日期列
                df['日期'] = 日期

                文件数 += 1
                print(f"已读取文件: {文件名}, 日期: {日期}, 累计处理文件数: {文件数}")

                文件列表.append(df)
            except Exception as e:
                print(f"读取文件 {文件名} 时发生错误: {e}")

    if 文件列表:
        # 将所有 DataFrame 合并
        df_总 = pd.concat(文件列表, ignore_index=True)

        # 将日期列设置为索引
        df_总.set_index('日期', inplace=True)

        # 将日期列复制到第一列
        df_总['日期'] = df_总.index

        # 调整列顺序，将日期列放在第一列
        列顺序 = ['日期'] + [col for col in df_总.columns if col != '日期']
        df_总 = df_总[列顺序]

        # 删除时分秒部分，只保留日期
        # df_总.index = pd.to_datetime(df_总.index)

    print(f"处理完成, 总共处理文件数: {文件数}")
    print('* ' * 30)
    df_总.columns = df_总.columns.str.strip()
    df_总.index.name = None
    return df_总




def 读取通达信day数据(股票代码列表, tdx_dir='C:/new_tdx', max_workers=4):
    """
    并行读取通达信本地数据，将所有股票的日线数据合并成一个 DataFrame。
    :param 股票代码列表: 股票代码的列表
    :param tdx_dir: 通达信数据目录
    :param max_workers: 最大并发线程数
    :return: 合并后的 DataFrame
    """
    # 创建 Reader 对象
    reader = Reader.factory(market='std', tdxdir=tdx_dir)

    # 读取单只股票数据的函数
    def 读取单只股票(代码):
        print(f"处理股票代码: {代码}")
        数据框 = reader.daily(symbol=代码)

        if 数据框.empty:
            print(f"{代码} 没有数据")
            return pd.DataFrame()

        # 确保索引是日期时间格式
        数据框.index = pd.to_datetime(数据框.index)

        # 复制索引列到第一列，并将其命名为 '日期'
        数据框['日期'] = 数据框.index

        # 添加股票代码列
        数据框['股票代码'] = 代码

        # 确保 '股票代码' 列在最后一列
        数据框 = 数据框[['日期', '股票代码'] + [col for col in 数据框.columns if col not in ['日期', '股票代码']]]

        return 数据框

    # 使用 concurrent.futures 并行处理
    所有数据 = pd.DataFrame()
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = executor.map(读取单只股票, 股票代码列表)

    # 合并所有结果
    所有数据 = pd.concat(results, ignore_index=False)

    return 所有数据


def 单个股票txt读取(file_path):
    # 提取文件名（去掉路径和后缀）
    文件名 = os.path.basename(file_path).replace('.txt', '')

    # 尝试读取文件内容，首先使用 'gbk' 编码，如果失败则使用 'latin1'
    try:
        with open(file_path, 'r', encoding='gbk') as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        with open(file_path, 'r', encoding='latin1') as f:
            lines = f.readlines()

    # 去掉第一行和最后一行，提取列名和数据
    列名 = lines[1].strip().split()  # 提取列名
    数据 = [line.strip().split(';') for line in lines[2:-1]]  # 提取数据行并按分号分隔

    # 将数据转换为 DataFrame
    df = pd.DataFrame(数据, columns=列名)

    # 增加一列为股票代码，并将其放置为第二列
    df.insert(1, '股票代码', 文件名)
    # 将“日期”列转换为 datetime 类型
    if '日期' in df.columns:
        df['日期'] = pd.to_datetime(df['日期'], errors='coerce')  # 无效日期将被转换为 NaT

    # 列名映射，将中文列名转换为英文列名
    列名映射 = {
        '开盘': 'open',
        '最高': 'high',
        '最低': 'low',
        '收盘': 'close',
        '成交量': 'volume',
        '成交额': 'amount'
    }
    # 应用列名映射
    df.rename(columns=列名映射, inplace=True)

    # 返回处理后的 DataFrame
    print(文件名)
    return df


def 批量读取通达信txt股票(file_folder):
    # 获取文件夹中所有 .txt 文件的路径
    file_paths = [os.path.join(file_folder, file) for file in os.listdir(file_folder) if file.endswith('.txt')]

    # 使用单个txt读取函数处理每个文件，并将结果存储在列表中
    df_list = [单个股票txt读取(file_path) for file_path in file_paths]

    # 将所有DataFrame拼接在一起
    combined_df = pd.concat(df_list, ignore_index=True)
    cols_to_convert = ['open', 'high', 'low', 'close', 'volume', 'amount']
    # 使用 pd.to_numeric() 将这些列批量转换为数值类型
    combined_df[cols_to_convert] = combined_df[cols_to_convert].apply(pd.to_numeric, errors='coerce')

    return combined_df



def 时间列对齐数据补全(df, group_column='股票代码'):
    # 获取所有唯一日期
    unique_dates = sorted(df['日期'].unique())

    # 定义一个内部函数，用于处理每只股票的数据
    def process_stock(stock_df):
        # 对数据按日期对齐
        stock_df_aligned = stock_df.set_index('日期').reindex(unique_dates)

        # 将 'amount' 和 'volume' 列的空值填充为 0
        stock_df_aligned['amount'] = stock_df_aligned['amount'].fillna(0)
        stock_df_aligned['volume'] = stock_df_aligned['volume'].fillna(0)

        # 对其他列进行前向和后向填充
        stock_df_filled = stock_df_aligned.ffill().bfill()

        # 将填充后的 DataFrame 重置索引
        return stock_df_filled.reset_index()

    # 对每只股票应用处理函数，使用动态指定的分组列名
    processed_dfs = [process_stock(group) for _, group in df.groupby(group_column)]

    # 合并所有处理过的 DataFrame
    aligned_df = pd.concat(processed_dfs, ignore_index=True)

    return aligned_df

def 日期(date_int):
    year = date_int // 10000
    month = (date_int % 10000) // 100
    day = date_int % 100
    return datetime.datetime(year, month, day)

def zhao(数据框, 日期整数=0, 股票代码=0, 排序列=None, 排序方式=0):
    """
    筛选并排序数据框中的数据。
    print( zhao(df,20240819,0,'SAR',0) )   参考
    参数:
    数据框 (pd.DataFrame): 要操作的数据框。
    日期整数 (int): 要筛选的日期，格式为 YYYYMMDD。如果为 0，则不进行日期筛选。
    股票代码 (int or str): 要筛选的股票代码。如果为 0，则不进行股票代码筛选。
    排序列 (str): 要排序的列名。如果为 None，则不进行排序。
    排序方式 (int): 排序方式，0 为降序，1 为升序。默认值为 0。

    返回:
    pd.DataFrame: 经过筛选和排序后的数据框。

    示例:
    1. 筛选日期:
        结果 = zhao(df, 20240816)

    2. 筛选日期和股票代码:
        结果 = zhao(df, 20240816, 1)  # 股票代码会被转换为 '000001'

    3. 筛选日期、股票代码，并按列排序:
        结果 = zhao(df, 20240816, 1, 排序列='国力天数', 排序方式=1)
    """
    # 如果日期不为 0，则将其转换为 datetime.date 对象并筛选数据
    if 日期整数 != 0:
        年 = 日期整数 // 10000
        月 = (日期整数 % 10000) // 100
        日 = 日期整数 % 100
        查询日期 = datetime.datetime(年, 月, 日)
        数据框 = 数据框[数据框['日期'] == 查询日期]

    # 将股票代码转换为字符串，并填充为6位
    if 股票代码 != 0:
        数据框 = 数据框[数据框['股票代码'] == str(股票代码).zfill(6)]  # 确保股票代码是6位

    # 如果提供了排序列，则进行排序
    if 排序列 is not None:
        升序 = True if 排序方式 == 1 else False
        数据框 = 数据框.sort_values(by=[排序列], ascending=升序)

    return 数据框

def 小数2点(num):
    """将数字格式化为两位小数的字符串形式"""
    # return "{:.4f}".format(num)
    return round(num, 2)


def 欺骗餐():
    df测试 = pd.DataFrame({
        'open': np.random.rand(100) * 100,
        'high': np.random.rand(100) * 100,
        'low': np.random.rand(100) * 100,
        'close': np.random.rand(100) * 100,
        'volume': np.random.randint(1, 1000, 100)
    }, index=pd.date_range(start='2020-01-01', periods=100, freq='B'))
    return df测试



def 所有股票交易点导出(df, str_排序列, 名次, 降序=0):
    # 默认降序 为 0  ，为1 为升序
    # 处理单个股票交易点
    def 单个股票交易点处理(x , str_排序列, 名次, 降序):
        # 根据降序的值决定升序或降序排序
        x = x.sort_values(by=str_排序列, ascending= 降序 )
        # 获取前 名次 个股票代码
        buy_date = list(x['股票代码'].values[:名次])
        return buy_date

    # 按日期分组并应用处理函数
    交易点 = df.groupby('日期').apply(lambda x: 单个股票交易点处理(x, str_排序列, 名次, 降序), include_groups=False)

    # 将结果转换为字典并返回
    交易点_dict_all = dict(交易点)
    return 交易点_dict_all


def 交易分析(analysis):
    """
    解析 Backtrader 的 TradeAnalyzer 结果，并计算胜率和盈亏比

    :param analysis: Backtrader TradeAnalyzer 的结果（AutoOrderedDict 格式）。
    :return: str 描述解析的交易分析结果，包括胜率和盈亏比。
    """
    # 提取数据，使用安全访问和默认值
    total_data = analysis.get('total', {})
    streak_data = analysis.get('streak', {})
    pnl_data = analysis.get('pnl', {})
    won_data = analysis.get('won', {})
    lost_data = analysis.get('lost', {})
    long_data = analysis.get('long', {})
    short_data = analysis.get('short', {})
    length_data = analysis.get('len', {})

    # 总交易次数
    total_trades = total_data.get('total', 0)
    open_trades = total_data.get('open', 0)
    closed_trades = total_data.get('closed', 0)

    # 连胜/连败统计
    current_winning_streak = streak_data.get('won', {}).get('current', 0)
    longest_winning_streak = streak_data.get('won', {}).get('longest', 0)
    current_losing_streak = streak_data.get('lost', {}).get('current', 0)
    longest_losing_streak = streak_data.get('lost', {}).get('longest', 0)

    # 盈亏统计
    gross_total = pnl_data.get('gross', {}).get('total', 0.0)
    gross_average = pnl_data.get('gross', {}).get('average', 0.0)
    net_total = pnl_data.get('net', {}).get('total', 0.0)
    net_average = pnl_data.get('net', {}).get('average', 0.0)

    # 盈利交易
    won_total = won_data.get('total', 0)
    won_pnl_total = won_data.get('pnl', {}).get('total', 0.0)
    won_pnl_average = won_data.get('pnl', {}).get('average', 0.0)
    won_pnl_max = won_data.get('pnl', {}).get('max', 0.0)

    # 亏损交易
    lost_total = lost_data.get('total', 0)
    lost_pnl_total = lost_data.get('pnl', {}).get('total', 0.0)
    lost_pnl_average = lost_data.get('pnl', {}).get('average', 0.0)
    lost_pnl_max = lost_data.get('pnl', {}).get('max', 0.0)

    # 多头交易
    long_total = long_data.get('total', 0)
    long_pnl_total = long_data.get('pnl', {}).get('total', 0.0)
    long_pnl_average = long_data.get('pnl', {}).get('average', 0.0)

    # 空头交易
    short_total = short_data.get('total', 0)
    short_pnl_total = short_data.get('pnl', {}).get('total', 0.0)
    short_pnl_average = short_data.get('pnl', {}).get('average', 0.0)

    # 交易时长
    total_length = length_data.get('total', 0)
    average_length = length_data.get('average', 0.0)
    max_length = length_data.get('max', 0)
    min_length = length_data.get('min', 0)

    # 计算胜率
    if total_trades > 0:
        win_rate = (won_total / total_trades) * 100
    else:
        win_rate = 0

    # 计算盈亏比
    if won_total > 0 and lost_total > 0:
        avg_profit = won_pnl_average
        avg_loss = abs(lost_pnl_average)
        profit_loss_ratio = avg_profit / avg_loss
    else:
        profit_loss_ratio = None

    # 构建易读的描述字符串
    result = f"交易分析结果：\n"
    result += f"总交易次数: {total_trades}, 未平仓交易: {open_trades}, 已平仓交易: {closed_trades}\n"
    result += f"连胜记录: 当前 {current_winning_streak} 次, 最长 {longest_winning_streak} 次\n"
    result += f"连败记录: 当前 {current_losing_streak} 次, 最长 {longest_losing_streak} 次\n"
    result += f"毛利润: 总计 {gross_total:.2f}, 平均每笔交易 {gross_average:.2f}\n"
    result += f"净利润: 总计 {net_total:.2f}, 平均每笔交易 {net_average:.2f}\n"
    result += f"交易成本: 总计 {net_total-gross_total:.2f}, 平均每笔_交易成本 {net_average-gross_average:.2f}\n"
    result += f"盈利交易: 总计 {won_total}, 总盈利 {won_pnl_total:.2f}, 平均盈利 {won_pnl_average:.2f}, 最大盈利 {won_pnl_max:.2f}\n"
    result += f"亏损交易: 总计 {lost_total}, 总亏损 {lost_pnl_total:.2f}, 平均亏损 {lost_pnl_average:.2f}, 最大亏损 {lost_pnl_max:.2f}\n"
    result += f"多头交易: 总计 {long_total}, 总盈亏 {long_pnl_total:.2f}, 平均盈亏 {long_pnl_average:.2f}\n"
    result += f"空头交易: 总计 {short_total}, 总盈亏 {short_pnl_total:.2f}, 平均盈亏 {short_pnl_average:.2f}\n"
    result += f"交易时长: 总计 {total_length} 天, 平均 {average_length:.2f} 天, 最长 {max_length} 天, 最短 {min_length} 天\n"

    # 添加胜率和盈亏比
    result += f"胜率: {win_rate:.2f}%\n"
    if profit_loss_ratio is not None:
        result += f"盈亏比: {profit_loss_ratio:.2f}\n"
    else:
        result += "无足够数据计算盈亏比\n"

    return result


