import numpy as np
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 生成 5000 个样本的特征数据 (1到5000) 和二分类目标数据 (1 表示奇数，0 表示偶数)
X = np.array([[i] for i in range(1, 5001)])  # 特征数据
y = np.array([1 if i % 2 == 1 else 0 for i in range(1, 5001)])  # 目标数据：奇数为1，偶数为0

# 数据打乱并分割为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)

# 初始化 SVC 分类模型（使用线性核函数）
svc = SVC(kernel='linear', C=1.0, probability=True)

# 训练模型
svc.fit(X_train, y_train)

# 进行预测
y_pred_classified = svc.predict(X_test)
y_pred_proba = svc.predict_proba(X_test)

# 计算分类准确率
accuracy = accuracy_score(y_test, y_pred_classified)

# 打印结果
print('测试集特征数据 X_test:')
print(X_test)
print('分类预测值:', y_pred_classified)
print('实际分类值:', y_test)
print('分类准确率:', accuracy)
