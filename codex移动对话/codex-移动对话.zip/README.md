# Codex Windows → Windows 一键迁移

现在只需要一个文件：

```text
Codex一键迁移.bat
```

BAT 可以放在桌面、U 盘或任意可写目录，**不需要复制进 `.codex`**。它会自动操作当前 Windows 用户的：

```text
%USERPROFILE%\.codex
```

## 菜单

双击 `Codex一键迁移.bat`：

```text
1. 打包旧电脑 Codex 数据
2. 解压并恢复到新电脑
0. 退出
```

也可以在命令行直接运行：

```bat
Codex一键迁移.bat 1
Codex一键迁移.bat 2
```

## 旧电脑打包

1. 完全退出 Codex。
2. 双击 `Codex一键迁移.bat`。
3. 输入 `1`。
4. ZIP 会生成在 BAT 所在目录：

```text
Codex-Windows-Migration-日期时间.zip
```

把下面两个文件复制到新电脑：

```text
Codex一键迁移.bat
Codex-Windows-Migration-日期时间.zip
```

打包内容包括会话、归档会话、线程索引、状态数据库、Skills、Plugins、Rules、Memory、Goals 和项目归组信息。

登录凭据、`config.toml`、设备安装标识、日志、运行缓存和 SQLite 临时文件默认排除。

> 外部项目源码不在 `%USERPROFILE%\.codex` 里，因此不会进入迁移 ZIP。需要源码时仍要另外复制项目目录。

## 新电脑解压恢复

1. 安装 Codex Desktop。
2. 启动并登录一次。
3. 完全退出 Codex。
4. 把迁移 ZIP 与 `Codex一键迁移.bat` 放在同一目录。
5. 双击 BAT，输入 `2`。

脚本会自动：

- 选择 BAT 同目录最新的迁移 ZIP；
- 校验 ZIP 中每个文件的 SHA-256；
- 备份新电脑当前 `.codex`；
- 合并会话、Skills、Plugins 和索引；
- 合并 `state_*.sqlite` 线程记录；
- 修正新旧 Windows 用户名和项目路径；
- 保留新电脑现有登录状态与 `config.toml`；
- 检查 SQLite 完整性；
- 创建缺失的空项目目录并尝试重新注册。

部署前备份位置：

```text
%USERPROFILE%\.codex-backup-before-migration-日期时间
```

## 环境要求

- Windows 10/11
- Windows PowerShell 5.1 或更高
- 新电脑已安装并登录过 Codex Desktop
- Python 3（恢复时用于安全合并 SQLite）

检查 Python：

```powershell
python -c "import sqlite3; print(sqlite3.sqlite_version)"
```

如果系统没有 `python`，脚本也会尝试：

```text
py -3
%USERPROFILE%\.cache\codex-runtimes\...\python.exe
```

## 常见问题

### 提示 Codex 正在运行

完全退出 Codex，再检查任务管理器。数据库写入期间不会强行打包或恢复。

### 提示找不到迁移 ZIP

把 `Codex-Windows-Migration-*.zip` 放到 BAT 同目录。脚本默认选择修改时间最新的一份。

### 只恢复出空项目文件夹

迁移包保存的是对话、项目路径和归组信息，不包含 `.codex` 外面的项目源码。把旧电脑源码另外复制到对应目录即可。

### 需要回滚

完全退出 Codex，把部署前生成的：

```text
%USERPROFILE%\.codex-backup-before-migration-日期时间
```

恢复为 `%USERPROFILE%\.codex`。确认迁移正确前不要删除该备份。

## 测试参数

以下环境变量用于自动化测试，普通双击不需要设置：

- `CODEX_MIGRATION_HOME`：覆盖 `.codex` 路径。
- `CODEX_MIGRATION_OUTPUT_DIR`：覆盖 ZIP 输出目录。
- `CODEX_MIGRATION_ZIP`：指定恢复 ZIP。
- `CODEX_MIGRATION_SKIP_RUNNING_CHECK=1`：跳过进程检查。
- `CODEX_MIGRATION_SKIP_APP_OPEN=1`：不自动注册项目。
- `CODEX_MIGRATION_NO_PAUSE=1`：结束后不暂停。
