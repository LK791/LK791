# Windows 到 Windows 一键迁移

使用说明已经合并到 [README.md](README.md)。

最终只使用：

```text
Codex一键迁移.bat
```

双击后输入：

- `1`：打包旧电脑 `%USERPROFILE%\.codex`
- `2`：解压、校验并恢复到新电脑 `%USERPROFILE%\.codex`
- `0`：退出

BAT 可以放在任意可写目录，不再要求复制进 `.codex`。打包生成的 ZIP 默认放在 BAT 同目录；恢复时也从 BAT 同目录寻找最新 ZIP。
